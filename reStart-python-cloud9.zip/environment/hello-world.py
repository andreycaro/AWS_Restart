print("Hello, Word")
